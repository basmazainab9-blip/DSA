#include <iostream>
using namespace std;

int main() {
    int n, index, value;

    cout << "Enter size of array: ";
    cin >> n;

    int arr[n];
    cout << "Enter array elements:\n";
    for(int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    cout << "Enter index to update: ";
    cin >> index;

    cout << "Enter new value: ";
    cin >> value;

    arr[index] = value;

    cout << "Updated array:\n";
    for(int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }

    return 0;
}
